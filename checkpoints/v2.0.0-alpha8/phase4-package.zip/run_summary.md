# Run summary — 2026-10-07-why-ice-cream-gives-you-brain-fr

| video | package | duration | title |
|---|---|---|---|
| v01 | passed | 32.62 s | Eating fast doubles your odds of brain freeze |
