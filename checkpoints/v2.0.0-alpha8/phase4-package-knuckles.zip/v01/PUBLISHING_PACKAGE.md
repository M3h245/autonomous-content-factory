# Publishing package — v01

Nothing is published automatically. Upload by hand; set the AI labels below.

## Public copy

**Title:** What actually pops when you crack your knuckles?

**Thumbnail:** `thumbnail.jpg` (text: “NOT BONES”) — crop preview in `thumbnail_crops.jpg` (9:16 · 4:5 · 3:4 · 1:1 · ≈3:2)

**YouTube description:**

```
That pop isn't your bones. Here's what an MRI saw.

Scientists filmed a knuckle cracking inside an MRI: the joint pulls apart and a gas cavity forms in the fluid.

Do you crack yours?

Narration: AI text-to-speech (kokoro-onnx). Visuals: doodle engine (Claude-authored SVG).

Sources:
- Real-time visualization of joint cavitation (PLoS ONE (Kawchuk et al., 2015)): https://doi.org/10.1371/journal.pone.0119470
- A mathematical model for the sounds produced by knuckle cracking (Scientific Reports (Chandran Suja & Barakat, 2018)): https://doi.org/10.1038/s41598-018-22664-4
- Knuckle cracking and hand osteoarthritis (Journal of the American Board of Family Medicine (deWeber et al., 2011)): https://doi.org/10.3122/jabfm.2011.02.100156

#science #humanbody #knucklecracking
```

**TikTok / Instagram caption:**

```
That pop isn't your bones. Here's what an MRI saw.

Scientists filmed a knuckle cracking inside an MRI: the joint pulls apart and a gas cavity forms in the fluid.

Do you crack yours?

#science #humanbody #knucklecracking
```

**CTA:** in video — Do you crack yours?; caption — Do you crack yours?

**AI labels:** YouTube altered/synthetic = False, TikTok AI-generated = True, Instagram AI info = True

**Video:** `final.mp4` (sha256 794442b4b0c2a1c8…)

## Covers

- **youtube:** Shorts custom thumbnail: YouTube Studio on desktop → this Short → Thumbnail → upload thumbnail.jpg (rolling out since 2026-07-25, Partner Program channels first; shown at ≈3:2 outside the Shorts feed — subject and text sit in the centre). If the option is not available on this channel, choose the closest frame instead.
- **tiktok:** Cover: desktop web upload → Edit cover → upload thumbnail.jpg (TikTok crops covers to 3:4; nothing important is outside the central square).
- **instagram:** Reels cover: Edit cover → Add from camera roll → thumbnail.jpg (profile grid crops to the centre).

## Before upload

- upload thumbnail.jpg as the cover on each platform (see covers)
- YouTube audience setting (made for kids: yes/no)
- confirm AI-label toggles
- publish time / schedule

## Why this package (internal)

Selected **P1** (curiosity), review total 45/45: title strength 5, curiosity 5, accuracy 5, thumbnail readability 5, complementarity 5, hook coherence 5, promise payoff 5, clickbait risk 5, cta coherence 5

Opening promise (caption first line): That pop isn't your bones. Here's what an MRI saw.
Thumbnail concept: huge fist, burst at the knuckles, 'NOT BONES' rules out the obvious answer
Claims rest on dossier facts ['f1', 'f2']; thumbnail depicts ['f1'] (research/dossier.json).

## Rejected alternatives

- **P2** “An MRI filmed a knuckle crack as it happened” / “GAS BUBBLE” — lower total review score (43 vs 45)
- **P3** “Does cracking your knuckles cause arthritis?” / “215 PEOPLE” — lower total review score (44 vs 45)
- **P4** “He cracked one hand for 60 years to test it” / “60 YEARS” — THUMB.NOT_IN_VIDEO (thumbnail): thumbnail words ['sixty', 'year'] are never said in the video (promise the video does not keep); TITLE.NOT_IN_VIDEO (title): title promises ['hand', 'one', 'sixty', 'test', 'year'], which the video never says; DESC.ON_TOPIC (description): description barely relates to the video
