# Not for upload — rejected by the independent judge (Phase 5)

These two folders are the last deliverables the factory generated for the flamingo and Moon videos. They passed the
factory's default (heuristic) QA and PACKAGE gates. A packet-only independent judge then failed both videos
(overall 3/5) and every package. With that judgment applied, the factory refuses to package them; their runs end in
`PACKAGE: rerun` (flamingo routed to HOOK, Moon to SCRIPT). Kept only so the owner can see what was rejected and why.
See PHASE_5_REPORT.md §2.
