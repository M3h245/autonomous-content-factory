# Publishing package — v01

Nothing is published automatically. Upload by hand; set the AI labels below.

## Public copy

**Title:** The giant horizon Moon isn't bigger

**Thumbnail:** `thumbnail.jpg` (text: “1.5% FARTHER”) — crop preview in `thumbnail_crops.jpg` (9:16 · 4:5 · 3:4 · 1:1 · ≈3:2)

**YouTube description:**

```
The giant Moon is actually a bit farther away.

At the horizon the Moon is about 1.5 percent farther from you than overhead, so it is very slightly smaller in the sky. The bigger look is an illusion.

Narration: AI text-to-speech (kokoro-onnx). Visuals: doodle engine (Claude-authored SVG).

Sources:
- The Moon Illusion: Why Does the Moon Look So Big Sometimes? (NASA Science): https://science.nasa.gov/solar-system/moon/the-moon-illusion-why-does-the-moon-look-so-big-sometimes/
- Why Does the Moon Look Larger at the Horizon? We Asked a NASA Scientist: Episode 50 (NASA): https://www.nasa.gov/general/why-does-the-moon-look-larger-at-the-horizon-we-asked-a-nasa-scientist-episode-50/
- Explaining the moon illusion (PNAS 97(1) (Kaufman & Kaufman, 2000)): https://www.pnas.org/doi/10.1073/pnas.97.1.500
- Why Does the Moon Look Bigger Near the Horizon? (Scientific American): https://www.scientificamerican.com/article/why-does-the-moon-look-bigger-near-the-horizon/
- Photographing the Moon Illusion (NASA Science): https://science.nasa.gov/resource/photographing-the-moon-illusion/
- Seeing Science: Solving the Mystery of the Shrinking Moon (Scientific American): https://www.scientificamerican.com/article/bring-science-home-shrinking-moon/

#moon #space #illusion #science
```

**TikTok / Instagram caption:**

```
The giant Moon is actually a bit farther away.

At the horizon the Moon is about 1.5 percent farther from you than overhead, so it is very slightly smaller in the sky. The bigger look is an illusion.

#moon #space #illusion #science
```

**CTA:** in video — none; caption — none

**AI labels:** YouTube altered/synthetic = False, TikTok AI-generated = True, Instagram AI info = True

**Video:** `final.mp4` (sha256 0af3b988cfe31a81…)

## Covers

- **youtube:** Shorts custom thumbnail: YouTube Studio on desktop → this Short → Thumbnail → upload thumbnail.jpg (rolling out since 2026-07-25, Partner Program channels first; shown at ≈3:2 outside the Shorts feed — subject and text sit in the centre). If the option is not available on this channel, choose the closest frame instead.
- **tiktok:** Cover: desktop web upload → Edit cover → upload thumbnail.jpg (TikTok crops covers to 3:4; nothing important is outside the central square).
- **instagram:** Reels cover: Edit cover → Add from camera roll → thumbnail.jpg (profile grid crops to the centre).

## Before upload

- upload thumbnail.jpg as the cover on each platform (see covers)
- YouTube audience setting (made for kids: yes/no)
- confirm AI-label toggles
- publish time / schedule

## Why this package (internal)

Selected **P2** (myth_bust), review total 44/45: title strength 5, curiosity 4, accuracy 5, thumbnail readability 5, complementarity 5, hook coherence 5, promise payoff 5, clickbait risk 5, cta coherence 5

Opening promise (caption first line): The giant Moon is actually a bit farther away.
Thumbnail concept: an eye looking at a big low moon along a distance line
Claims rest on dossier facts ['f2', 'f3']; thumbnail depicts ['f2'] (research/dossier.json).

## Rejected alternatives

- **P1** “Your camera says the Moon never grew” / “SAME WIDTH” — lower total review score (44 vs 44) (tie broken by accuracy, clickbait safety, shorter title)
- **P3** “Your brain sees the horizon Moon bigger” / “FAR AWAY” — lower total review score (43 vs 44): curiosity 3 vs 4
