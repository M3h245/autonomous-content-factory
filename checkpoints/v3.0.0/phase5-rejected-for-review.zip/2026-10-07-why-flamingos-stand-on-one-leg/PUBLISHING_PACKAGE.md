# Publishing package — v01

Nothing is published automatically. Upload by hand; set the AI labels below.

## Public copy

**Title:** Why flamingos rest on one leg

**Thumbnail:** `thumbnail.jpg` (text: “SWAYED LESS”) — crop preview in `thumbnail_crops.jpg` (9:16 · 4:5 · 3:4 · 1:1 · ≈3:2)

**YouTube description:**

```
Two clues to why flamingos rest on one leg.

In 2017, a dead flamingo propped on one leg held steady with no muscle working. A 2010 zoo study found more birds did it in water and in the cold, which may save heat.

Narration: AI text-to-speech (kokoro-onnx). Visuals: doodle engine (Claude-authored SVG).

Sources:
- Mechanical evidence that flamingos can support their body on one leg with little active muscular force (Biology Letters (Chang & Ting, 2017)): https://doi.org/10.1098/rsbl.2016.0948
- Scientists Pinpoint How A Flamingo Balances On One Leg (NPR): https://www.npr.org/sections/thetwo-way/2017/05/25/530046238/scientists-pinpoint-how-a-flamingo-balances-on-one-leg
- How a flamingo balances on one leg (Science News): https://www.sciencenews.org/article/how-flamingo-balances-one-leg
- Why do flamingos stand on one leg? (Zoo Biology 29(3) (Anderson & Williams, 2010)): https://pubmed.ncbi.nlm.nih.gov/19637281/
- Why Flamingos Stand on One Leg (Live Science): https://www.livescience.com/5732-flamingos-stand-leg.html
- Flamingo hows, wheres and whys: Pink; erectile tissue; one leg (Scientific American (blog)): https://www.scientificamerican.com/blog/running-ponies/flamingo-hows-wheres-and-whys-pink-errectile-tissue-one-leg
- Tech Study Stands Up for Flamingos' Unique Pose (Georgia Institute of Technology): https://neuro.gatech.edu/tech-study-stands-flamingos-unique-pose
- How Do Flamingos Stay Stable On One Leg? (Smithsonian Magazine): https://www.smithsonianmag.com/smart-news/study-explores-how-flamingos-stay-stable-one-leg-180963440/

#flamingo #animals #science #biology
```

**TikTok / Instagram caption:**

```
Two clues to why flamingos rest on one leg.

In 2017, a dead flamingo propped on one leg held steady with no muscle working. A 2010 zoo study found more birds did it in water and in the cold, which may save heat.

#flamingo #animals #science #biology
```

**CTA:** in video — none; caption — none

**AI labels:** YouTube altered/synthetic = False, TikTok AI-generated = True, Instagram AI info = True

**Video:** `final.mp4` (sha256 733a5bbaf6a71a32…)

## Covers

- **youtube:** Shorts custom thumbnail: YouTube Studio on desktop → this Short → Thumbnail → upload thumbnail.jpg (rolling out since 2026-07-25, Partner Program channels first; shown at ≈3:2 outside the Shorts feed — subject and text sit in the centre). If the option is not available on this channel, choose the closest frame instead.
- **tiktok:** Cover: desktop web upload → Edit cover → upload thumbnail.jpg (TikTok crops covers to 3:4; nothing important is outside the central square).
- **instagram:** Reels cover: Edit cover → Add from camera roll → thumbnail.jpg (profile grid crops to the centre).

## Before upload

- upload thumbnail.jpg as the cover on each platform (see covers)
- YouTube audience setting (made for kids: yes/no)
- confirm AI-label toggles
- publish time / schedule

## Why this package (internal)

Selected **P1** (question), review total 45/45: title strength 5, curiosity 5, accuracy 5, thumbnail readability 5, complementarity 5, hook coherence 5, promise payoff 5, clickbait risk 5, cta coherence 5

Opening promise (caption first line): Two clues to why flamingos rest on one leg.
Thumbnail concept: flamingo asleep on one leg on a force plate, sway marks either side
Claims rest on dossier facts ['f2', 'f5', 'f6', 'f7', 'f8']; thumbnail depicts ['f5'] (research/dossier.json).

## Rejected alternatives

- **P2** “A dead flamingo held steady on one leg” / “NO MUSCLE” — lower total review score (44 vs 45): curiosity 4 vs 5
- **P3** “One leg in cold water may save heat” / “2010 STUDY” — lower total review score (43 vs 45): curiosity 3 vs 5
