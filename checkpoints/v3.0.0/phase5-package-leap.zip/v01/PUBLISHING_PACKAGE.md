# Publishing package — v01

Nothing is published automatically. Upload by hand; set the AI labels below.

## Public copy

**Title:** Leap years aren't every four years

**Thumbnail:** `thumbnail.jpg` (text: “NOT IN 1900”) — crop preview in `thumbnail_crops.jpg` (9:16 · 4:5 · 3:4 · 1:1 · ≈3:2)

**YouTube description:**

```
Leap years aren't every four years.

A century year is a leap year only if it divides by 400: 2000 was, 1900 was not, and 2100 will not be. The rule keeps the calendar in step with the seasons.

Narration: AI text-to-speech (kokoro-onnx). Visuals: doodle engine (Claude-authored SVG).

Sources:
- Gregorian calendar (Encyclopaedia Britannica): https://www.britannica.com/topic/Gregorian-calendar
- Leap Day, February 29 (Encyclopaedia Britannica): https://www.britannica.com/story/leap-day-february-29
- Introduction to Calendars (U.S. Naval Observatory): https://aa.usno.navy.mil/faq/calendars
- Which years are leap years and can you have leap seconds? (Royal Museums Greenwich): https://www.rmg.co.uk/stories/time/which-years-are-leap-years-can-you-have-leap-seconds
- Calendar Calculations (NASA Glenn Research Center): https://www.grc.nasa.gov/www/k-12/Numbers/Math/Mathematical_Thinking/calendar_calculations.htm
- Calendar: The Gregorian calendar (Encyclopaedia Britannica): https://www.britannica.com/science/calendar/The-Gregorian-calendar

#LeapYear #calendar #history #science
```

**TikTok / Instagram caption:**

```
Leap years aren't every four years.

A century year is a leap year only if it divides by 400: 2000 was, 1900 was not, and 2100 will not be. The rule keeps the calendar in step with the seasons.

#LeapYear #calendar #history #science
```

**CTA:** in video — none; caption — none

**AI labels:** YouTube altered/synthetic = False, TikTok AI-generated = True, Instagram AI info = True

**Video:** `final.mp4` (sha256 447c54e60915ebf5…)

## Covers

- **youtube:** Shorts custom thumbnail: YouTube Studio on desktop → this Short → Thumbnail → upload thumbnail.jpg (rolling out since 2026-07-25, Partner Program channels first; shown at ≈3:2 outside the Shorts feed — subject and text sit in the centre). If the option is not available on this channel, choose the closest frame instead.
- **tiktok:** Cover: desktop web upload → Edit cover → upload thumbnail.jpg (TikTok crops covers to 3:4; nothing important is outside the central square).
- **instagram:** Reels cover: Edit cover → Add from camera roll → thumbnail.jpg (profile grid crops to the centre).

## Before upload

- upload thumbnail.jpg as the cover on each platform (see covers)
- YouTube audience setting (made for kids: yes/no)
- confirm AI-label toggles
- publish time / schedule

## Why this package (internal)

Selected **P1** (myth_bust), review total 41/45: title strength 4, curiosity 4, accuracy 5, thumbnail readability 4, complementarity 5, hook coherence 5, promise payoff 5, clickbait risk 4, cta coherence 5

Opening promise (caption first line): Leap years aren't every four years.
Thumbnail concept: a February page with day 29 crossed out
Claims rest on dossier facts ['f3', 'f6']; thumbnail depicts ['f6'] (research/dossier.json).

## Rejected alternatives

- **P2** “Why 1900 had no leap day” / “÷ 400” — review thumbnail_readability: 3<4; review hook_coherence: 3<4
- **P3** “In 1582, ten days were dropped” / “−10 DAYS” — review curiosity: 2<3; review complementarity: 2<4; review hook_coherence: 2<4
- **P4** “Why century years skip leap day” / “365.25” — review hook_coherence: 3<4
