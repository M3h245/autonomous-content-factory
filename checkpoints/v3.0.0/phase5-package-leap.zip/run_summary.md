# Run summary — 2026-10-07-why-leap-years-skip-some-century

| video | package | duration | title |
|---|---|---|---|
| v01 | passed | 38.13 s | Leap years aren't every four years |
