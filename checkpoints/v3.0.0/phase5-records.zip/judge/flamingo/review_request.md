# Independent review request

You are a fresh reviewer. Read ONLY the files in this packet:
`/tmp/claude-0/-home-user-autonomous-content-factory/55d2e87d-e7fb-534d-84e9-f6886caeb7b7/scratchpad/p5/judge/flamingo/video_packet` (see manifest.json). Do not open anything else.

Score each dimension 1-5 (1 unacceptable, 2 weak, 3 acceptable, 4 strong, 5 publish-ready) for a vertical short-form explainer. Dimensions: hook_strength, first_frame_clarity, message_clarity, visual_verbal_sync, pacing_retention, audio_balance, subtitle_readability, ending_quality, title_coherence, thumbnail_coherence, overall_publishability. For EVERY dimension give concise visual/audio evidence from the packet; for every score below 4 give an explanation of what fails and what would fix it. Judge only what is in the packet. Return ONLY JSON: {"<dimension>": {"score": int, "evidence": str, "explanation": str}, ...}

Write the JSON to `/tmp/claude-0/-home-user-autonomous-content-factory/55d2e87d-e7fb-534d-84e9-f6886caeb7b7/scratchpad/p5/judge/flamingo/video_review/judgment.json` and stop.

Objective failures already found:
```json
[]
```
