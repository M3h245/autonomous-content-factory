# Script variants

selected: **B** · distinct: True {'role_sequences_differ': True, 'rhythm_differs': True, 'body_word_overlap': 0.62, 'rhythm_a': {'sentences': 9, 'mean_words': 10.33, 'std_words': 4.08}, 'rhythm_b': {'sentences': 7, 'mean_words': 8.86, 'std_words': 3.56}}

| variant | structure | est s | clarity | pacing | payoff | hook | verdict |
|---|---|---|---|---|---|---|---|
| A | contradiction (camera vs eyes) → photo proof → not giant → farther → leading explanation → still debated → fingernail test → paper tube + integrated save CTA (8 beats) | 35.94 | 4 | 4 | 4 | 4 | FAIL |
| B | contradiction → photo proof → farther → it's your brain → explanation → debated → paper tube (7 beats, no CTA) | 25.43 | 4 | 4 | 4 | 4 | PASS |
