# Hook selection — Why the Moon looks bigger near the horizon

selected: **h5**

| id | mechanism | spoken | on screen | est s | hook | frame 0 | coherence | verdict |
|---|---|---|---|---|---|---|---|---|
| h1 | misconception_reversal | That huge horizon Moon isn't actually bigger. | NOT BIGGER | 2.77 | 4 | 5 | 5 | PASS |
| h2 | surprising_claim | The rising Moon is actually a bit farther away. | FARTHER AWAY | 3.3 | 4 | 5 | 5 | PASS |
| h3 | direct_challenge | Hold up a fingernail: does the giant Moon shrink? | DOES IT SHRINK? | 3.0 | 4 | 5 | 5 | PASS |
| h4 | visual_mystery | Same Moon, two sizes. Which one is real? | SAME MOON? | 2.84 | 4 | 5 | 5 | PASS |
| h5 | contradiction | Your camera says the Moon never grew. | CAMERA SAYS SAME | 2.44 | 4 | 5 | 5 | PASS |
