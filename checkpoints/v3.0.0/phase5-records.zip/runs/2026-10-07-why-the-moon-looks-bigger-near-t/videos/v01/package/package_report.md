# Package selection

Status: **failed**

| id | strategy | title | thumb | accuracy | clickbait risk | complementarity | cta coherence | curiosity | hook coherence | promise payoff | thumbnail readability | title strength | total | pass |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| P1 | contrast | Your camera says the Moon never grew | SAME WIDTH | 5 | 5 | 3 | 5 | 4 | 5 | 4 | 5 | 4 | 40 | ✗ |
| P2 | myth_bust | The giant horizon Moon isn't bigger | 1.5% FARTHER | 4 | 4 | 5 | 5 | 4 | 3 | 4 | 5 | 5 | 39 | ✗ |
| P3 | mechanism | Your brain sees the horizon Moon bigger | FAR AWAY | 4 | 5 | 5 | 5 | 3 | 4 | 4 | 4 | 3 | 37 | ✗ |

## Rejected
- **P1** — Your camera says the Moon never grew: review complementarity: 3<4
- **P2** — The giant horizon Moon isn't bigger: review hook_coherence: 3<4
- **P3** — Your brain sees the horizon Moon bigger: review title_strength: 3<4
