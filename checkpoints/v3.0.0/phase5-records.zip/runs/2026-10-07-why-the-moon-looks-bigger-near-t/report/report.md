# Run report — 2026-10-07-why-the-moon-looks-bigger-near-t

Topic: Why the Moon looks bigger near the horizon

| stage | video | final | records | failures | wall s | gate s | failed (per attempt) | cache |
|---|---|---|---|---|---|---|---|---|
| RESEARCH | — | passed | 1 | 0 | 0.15 | 0.0 | a1: — |  |
| IDEATION | — | passed | 1 | 0 | 0.16 | 0.0 | a1: — |  |
| SELECTION | — | passed | 1 | 0 | 0.14 | 0.0 | a1: — |  |
| HOOK | v01 | passed | 3 | 1 | 80.02 | 80.0 | a1: HOOK.SELECTED; a2: —; a1: — |  |
| SCRIPT | v01 | passed | 4 | 1 | 1.97 | 3.0 | a1: —; a1: —; a1: SCRIPT.SELECTED; a2: — |  |
| AUDIO | v01 | passed | 3 | 0 | 56.4 | 56.0 | a1: —; a2: —; a1: — | 2 hit / 5 miss |
| VISUAL_PLAN | v01 | passed | 3 | 0 | 32.54 | 32.0 | a1: —; a2: —; a1: — |  |
| VIDEO | v01 | passed | 3 | 1 | 197.63 | 197.0 | a1: VID.EMPTY_FRAMES,VID.TEXT_CROPPED; a2: —; a1: — |  |
| SUBTITLES | v01 | passed | 2 | 0 | 54.99 | 55.0 | a1: —; a1: — |  |
| QA | v01 | passed | 4 | 0 | 45.89 | 34.0 | a1: —; a1: —; a1: —; a1: — |  |
| PACKAGE | v01 | failed | 5 | 2 | 18.51 | 34.0 | a1: —; a1: —; a1: PKG.PACKAGING; a2: —; a1: PKG.PACKAGING |  |

Total stage wall time: 488.4 s · failed attempts: 5 · regenerations: 7 · escalations: 0 · human resets: 2

Package v01: /tmp/claude-0/-home-user-autonomous-content-factory/55d2e87d-e7fb-534d-84e9-f6886caeb7b7/scratchpad/p5/runs/2026-10-07-why-the-moon-looks-bigger-near-t/package/v01 (CREDITS.txt, PUBLISHING_PACKAGE.md, captions.srt, captions.vtt, contact_sheet.jpg, cover.jpg, final.mp4, media_metadata_audit.json, metadata.json, provenance.json, provenance_result.json, publishing_package.json, qa_report.json, result.json, thumbnail.jpg, thumbnail_crops.jpg)
