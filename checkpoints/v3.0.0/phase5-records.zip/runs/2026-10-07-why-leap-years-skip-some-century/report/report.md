# Run report — 2026-10-07-why-leap-years-skip-some-century

Topic: Why leap years skip some century years

| stage | video | final | records | failures | wall s | gate s | failed (per attempt) | cache |
|---|---|---|---|---|---|---|---|---|
| RESEARCH | — | passed | 1 | 0 | 0.16 | 0.0 | a1: — |  |
| IDEATION | — | passed | 1 | 0 | 0.15 | 0.0 | a1: — |  |
| SELECTION | — | passed | 1 | 0 | 0.12 | 0.0 | a1: — |  |
| HOOK | v01 | passed | 1 | 0 | 35.27 | 35.0 | a1: — |  |
| SCRIPT | v01 | passed | 1 | 0 | 0.54 | 0.0 | a1: — |  |
| AUDIO | v01 | passed | 1 | 0 | 33.47 | 33.0 | a1: — | 1 hit / 11 miss |
| VISUAL_PLAN | v01 | passed | 2 | 0 | 20.56 | 21.0 | a1: —; a2: — |  |
| VIDEO | v01 | passed | 2 | 1 | 144.69 | 144.0 | a1: VID.OVERHANG; a2: — |  |
| SUBTITLES | v01 | passed | 1 | 0 | 31.04 | 31.0 | a1: — |  |
| QA | v01 | passed | 2 | 0 | 26.28 | 20.0 | a1: —; a1: — |  |
| PACKAGE | v01 | passed | 5 | 2 | 24.4 | 44.0 | a1: PKG.PACKAGING; a2: PKG.PACKAGING; a3: —; a1: —; a1: — |  |

Total stage wall time: 316.7 s · failed attempts: 3 · regenerations: 3 · escalations: 0 · human resets: 0

Package v01: /tmp/claude-0/-home-user-autonomous-content-factory/55d2e87d-e7fb-534d-84e9-f6886caeb7b7/scratchpad/p5/runs/2026-10-07-why-leap-years-skip-some-century/package/v01 (CREDITS.txt, PUBLISHING_PACKAGE.md, captions.srt, captions.vtt, contact_sheet.jpg, cover.jpg, final.mp4, media_metadata_audit.json, metadata.json, provenance.json, provenance_result.json, publishing_package.json, qa_report.json, result.json, thumbnail.jpg, thumbnail_crops.jpg)
