# Hook selection — Why leap years skip some century years

selected: **h2**

| id | mechanism | spoken | on screen | est s | hook | frame 0 | coherence | verdict |
|---|---|---|---|---|---|---|---|---|
| h1 | surprising_claim | The year 1900 had no leap day. | NO FEB 29 | 2.91 | 4 | 5 | 5 | PASS |
| h2 | misconception_reversal | Leap years aren't every four years. | NOT EVERY 4 | 2.18 | 4 | 5 | 5 | PASS |
| h3 | quiz | Quick: was 2000 a leap year? | 2000: LEAP? | 2.31 | 4 | 5 | 5 | PASS |
| h4 | question | Why do century years skip leap day? | CENTURY YEARS? | 2.21 | 4 | 5 | 5 | PASS |
| h5 | prediction | Every four years? Not in 2100. | 2100: NO LEAP DAY | 3.16 | 4 | 5 | 5 | PASS |
