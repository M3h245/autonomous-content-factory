# Script variants

selected: **B** · distinct: True {'role_sequences_differ': True, 'rhythm_differs': False, 'body_word_overlap': 0.47, 'rhythm_a': {'sentences': 11, 'mean_words': 8.09, 'std_words': 5.05}, 'rhythm_b': {'sentences': 12, 'mean_words': 7.08, 'std_words': 4.8}}

| variant | structure | est s | clarity | pacing | payoff | hook | verdict |
|---|---|---|---|---|---|---|---|
| A | myth → almost (1900) → the real year + overshoot → 10-day drift → 1582 jump → payoff (divide by 400) → 2000 vs 2100 → loop + share CTA (8 beats) | 41.52 | 3 | 4 | 3 | 4 | FAIL |
| B | myth → rule first → three example years → why: the real year → overshoot → 10 days dropped → payoff (3 skips per 400 years) → loop (8 beats, no CTA) | 39.67 | 4 | 4 | 4 | 4 | PASS |
