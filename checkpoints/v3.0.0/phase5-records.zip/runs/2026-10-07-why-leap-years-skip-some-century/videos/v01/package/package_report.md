# Package selection

Status: **passed**

Selected: **P1** (myth_bust) — total 41
- Title: Leap years aren't every four years
- Thumbnail text: NOT IN 1900 — a February page with day 29 crossed out
- Opening promise: Leap years aren't every four years.

| id | strategy | title | thumb | accuracy | clickbait risk | complementarity | cta coherence | curiosity | hook coherence | promise payoff | thumbnail readability | title strength | total | pass |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| P1 | myth_bust | Leap years aren't every four years | NOT IN 1900 | 5 | 4 | 5 | 5 | 4 | 5 | 5 | 4 | 4 | 41 | ✓ |
| P2 | curiosity | Why 1900 had no leap day | ÷ 400 | 5 | 5 | 4 | 5 | 4 | 3 | 4 | 3 | 4 | 37 | ✗ |
| P3 | story | In 1582, ten days were dropped | −10 DAYS | 4 | 3 | 2 | 5 | 2 | 2 | 2 | 4 | 4 | 28 | ✗ |
| P4 | mechanism | Why century years skip leap day | 365.25 | 4 | 4 | 4 | 5 | 4 | 3 | 5 | 4 | 4 | 37 | ✗ |

## Rejected
- **P2** — Why 1900 had no leap day: review thumbnail_readability: 3<4; review hook_coherence: 3<4
- **P3** — In 1582, ten days were dropped: review curiosity: 2<3; review complementarity: 2<4; review hook_coherence: 2<4; review promise_payoff: 2<4
- **P4** — Why century years skip leap day: review hook_coherence: 3<4
