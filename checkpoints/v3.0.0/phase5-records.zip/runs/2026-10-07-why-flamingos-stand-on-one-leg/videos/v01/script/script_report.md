# Script variants

selected: **B** · distinct: True {'role_sequences_differ': True, 'rhythm_differs': True, 'body_word_overlap': 0.5, 'rhythm_a': {'sentences': 11, 'mean_words': 9.0, 'std_words': 4.24}, 'rhythm_b': {'sentences': 9, 'mean_words': 7.78, 'std_words': 3.22}}

| variant | structure | est s | clarity | pacing | payoff | hook | verdict |
|---|---|---|---|---|---|---|---|
| A | question → dead-flamingo test at once → one leg holds with no muscle → two legs fail → little effort → zoo birds asleep → 2010 water/cold clue → payoff (armchair) → loop (9 beats, no CTA) | 37.86 | 4 | 4 | 4 | 4 | PASS |
| B | question → test first → two legs fail → sleep sway → cold-water clue → payoff (7 beats, no CTA) | 26.43 | 4 | 4 | 4 | 4 | PASS |
