# Package selection

Status: **failed**

| id | strategy | title | thumb | accuracy | clickbait risk | complementarity | cta coherence | curiosity | hook coherence | promise payoff | thumbnail readability | title strength | total | pass |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| P1 | question | Why flamingos rest on one leg | SWAYED LESS | 4 | 5 | 4 | 5 | 3 | 5 | 4 | 4 | 3 | 37 | ✗ |
| P2 | myth_bust | A dead flamingo held steady on one leg | NO MUSCLE | 4 | 4 | 3 | 5 | 4 | 4 | 4 | 4 | 5 | 37 | ✗ |
| P3 | utility | One leg in cold water may save heat | 2010 STUDY | 3 | 4 | 3 | 5 | 2 | 3 | 2 | 4 | 3 | 29 | ✗ |

## Rejected
- **P1** — Why flamingos rest on one leg: review title_strength: 3<4
- **P2** — A dead flamingo held steady on one leg: review complementarity: 3<4
- **P3** — One leg in cold water may save heat: review title_strength: 3<4; review curiosity: 2<3; review accuracy: 3<4; review complementarity: 3<4
