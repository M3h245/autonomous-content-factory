# Hook selection — Why flamingos stand on one leg

selected: **h4**

| id | mechanism | spoken | on screen | est s | hook | frame 0 | coherence | verdict |
|---|---|---|---|---|---|---|---|---|
| h1 | surprising_claim | How does a dead flamingo stay on one leg? | DEAD, ON ONE LEG? | 2.74 | 4 | 4 | 5 | FAIL |
| h2 | misconception_reversal | One leg isn't a balancing act for flamingos. | NOT A BALANCING ACT | 2.87 | 4 | 4 | 5 | FAIL |
| h3 | visual_mystery | Why doesn't a sleeping flamingo fall over? | SLEEPING, NOT FALLING | 2.54 | 4 | 3 | 5 | FAIL |
| h4 | question | Why do flamingos rest on one leg? | WHY ONE LEG? | 2.21 | 4 | 5 | 5 | PASS |
| h5 | direct_challenge | Try sleeping on one leg like a flamingo. | COULD YOU? | 2.71 | — | — | — | repeated_failed |
