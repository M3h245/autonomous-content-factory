# Run summary — 2026-10-07-why-flamingos-stand-on-one-leg

| video | package | duration | title |
|---|---|---|---|
| v01 | failed | — s | — |
