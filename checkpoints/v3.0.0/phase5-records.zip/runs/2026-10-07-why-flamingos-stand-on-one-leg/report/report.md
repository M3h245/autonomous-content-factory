# Run report — 2026-10-07-why-flamingos-stand-on-one-leg

Topic: Why flamingos stand on one leg

| stage | video | final | records | failures | wall s | gate s | failed (per attempt) | cache |
|---|---|---|---|---|---|---|---|---|
| RESEARCH | — | passed | 1 | 0 | 0.14 | 0.0 | a1: — |  |
| IDEATION | — | passed | 1 | 0 | 0.13 | 0.0 | a1: — |  |
| SELECTION | — | passed | 1 | 0 | 0.15 | 0.0 | a1: — |  |
| HOOK | v01 | passed | 2 | 0 | 73.69 | 72.0 | a1: —; a1: — |  |
| SCRIPT | v01 | passed | 3 | 0 | 1.69 | 1.0 | a1: —; a1: —; a2: — |  |
| AUDIO | v01 | passed | 3 | 0 | 86.29 | 85.0 | a1: —; a2: —; a3: — | 3 hit / 6 miss |
| VISUAL_PLAN | v01 | passed | 3 | 0 | 30.76 | 29.0 | a1: —; a2: —; a3: — |  |
| VIDEO | v01 | passed | 6 | 2 | 327.56 | 325.0 | a1: —; a1: —; a2: —; a3: VID.SPEECH_MASKING; a1: VID.SPEECH_MASKING; a2: — |  |
| SUBTITLES | v01 | passed | 3 | 0 | 109.68 | 109.0 | a1: —; a2: —; a1: — |  |
| QA | v01 | passed | 6 | 0 | 151.83 | 117.0 | a1: —; a1: —; a2: —; a2: —; a1: —; a1: — |  |
| PACKAGE | v01 | failed | 7 | 3 | 49.05 | 66.0 | a1: PKG.PACKAGING; a2: —; a1: —; a3: PKG.PACKAGING; a1: —; a1: —; a1: PKG.PACKAGING |  |

Total stage wall time: 831.0 s · failed attempts: 5 · regenerations: 10 · escalations: 2 · human resets: 5

Package v01: /tmp/claude-0/-home-user-autonomous-content-factory/55d2e87d-e7fb-534d-84e9-f6886caeb7b7/scratchpad/p5/runs/2026-10-07-why-flamingos-stand-on-one-leg/package/v01 (CREDITS.txt, PUBLISHING_PACKAGE.md, captions.srt, captions.vtt, contact_sheet.jpg, cover.jpg, final.mp4, media_metadata_audit.json, metadata.json, provenance.json, provenance_result.json, publishing_package.json, qa_report.json, result.json, thumbnail.jpg, thumbnail_crops.jpg)
